# -*- coding: utf-8 -*-
import scrapy
from shiyanlou.items import ShiyanlouItem

class GithubSpider(scrapy.Spider):
    name = 'github'
    #@property
    def start_requests(self):
        url_tmpl = 'https://github.com/shiyanlou?page={}&tab=repositories'
        urls = (url_tmpl.format(i) for i in range(1, 4))
        for url in urls:
            yield scrapy.Request(url=url,callback=self.parse)

    def parse(self, response):
        for sel in response.xpath('//ul[@data-filterable-for="your-repos-filter"]/li'):

            itme = ShiyanlouItem({'name':sel.xpath('.//h3/a/text()').re_first('[^\w]*(\w+)[^\w]*'),
                'update_time':sel.xpath('.//relative-time/@datetime').extract_first(),
                })
            yield itme       

